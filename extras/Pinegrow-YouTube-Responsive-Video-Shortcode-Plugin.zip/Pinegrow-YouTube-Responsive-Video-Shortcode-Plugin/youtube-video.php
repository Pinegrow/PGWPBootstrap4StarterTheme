<?php
/**
 * 	Plugin Name: 	Pinegrow YouTube Responsive Video Shortcode Plugin
 * 	Plugin URI: 	http://pinegrow.com
 * 	Description: 	Example [youtube id="BK6pKsEq4FA"]
 * 	Author: 		Pinegrow Team
 * 	Author URI: 	http://pinegrow.com
 *
 *
 * 	Version: 		1.0
 * 	License: 		GPLv2
 *
 *  The Pinegrow YouTube Responsive Video Shortcode Plugin is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  any later version.
 *
 *  The Pinegrow YouTube Responsive Video Shortcode Plugin is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with WP Functional Plugin. If not, see <http://www.gnu.org/licenses/>.
 */

 // Register the shortcode to wrap html around the Youtube video content
 // Inspiration 1: http://www.wpstuffs.com/youtube-videos-responsive-wordpress/
 // Inspiration 2: https://code.tutsplus.com/tutorials/creating-a-shortcode-for-responsive-video--wp-32469
 // Inspiration 3: http://www.vtubetools.com/
 // Option: &playlist=' . $identifier . '

 function pg_doc_youtube_video_shortcode( $atts ) {
     extract( shortcode_atts( array (
         'id' => ''
     ), $atts ) );
     return '<div class="video-container"><iframe width="320" height="240" src="//www.youtube.com/embed/' . $id . '?&rel=0&theme=light&loop=1&showinfo=1&modestbranding=1&hd=1&autohide=1" frameborder="0" allowfullscreen></iframe></div>';
 }
 add_shortcode ('youtube', 'pg_doc_youtube_video_shortcode' );

 // Register stylesheet with hook 'wp_enqueue_scripts', which can be used for front end CSS and JavaScript
 function pg_doc_youtube_video_add_stylesheet() {
     wp_register_style( 'pg_doc_youtube_video_style', plugins_url( 'youtube-video.css', __FILE__ ) );
     wp_enqueue_style( 'pg_doc_youtube_video_style' );
 }
 add_action( 'wp_enqueue_scripts', 'pg_doc_youtube_video_add_stylesheet' );
